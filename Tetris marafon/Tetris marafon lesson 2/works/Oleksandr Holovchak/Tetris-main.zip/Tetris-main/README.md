* In lesson 1 i have created a game board and pieces with dynamic color selection
https://oleksandr511.github.io/Tetris/
