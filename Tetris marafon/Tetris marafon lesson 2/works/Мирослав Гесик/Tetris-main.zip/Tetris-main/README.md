Game from marathon Front-end developer.
See more here https://edu.cbsystematics.com/ua/marathon/tetris
