// import { $ } from "../constants/_constants.js";

// function setBodyHeight() {
//     const MAIN = $(".main");
//     const windowHeight = window.innerHeight;
//     const headerHeight = $(".header").offsetHeight;

//     MAIN.style.marginTop = `${headerHeight}px`;

//     if ( windowHeight <= 688 ) { return };

//     const footerHeight = $(".footer").offsetHeight;

//     MAIN.style.height = `${windowHeight - (headerHeight + footerHeight)}px`;
// }

// setBodyHeight();
