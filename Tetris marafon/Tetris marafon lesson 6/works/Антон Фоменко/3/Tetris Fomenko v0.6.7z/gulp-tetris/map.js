tetrominoFalls {
    moveTetrominoDown {
        placeTetromino {//1
            isLevelUp()

            removeFillRow {//2
                findFillRow//3
                blimBlimFillRow {//4
                    dropLine()//5
                }
            }
            generateTetromino {//6
                generateColorForTetromino()
            }
        }
    }
    draw {
        drawPlayField()
        drawNextTetrominoField()
        drawTetromino()
        drawNextTetromino()
    }
}
